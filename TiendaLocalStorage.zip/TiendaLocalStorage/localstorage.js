//crear coleccion de datos

// let productos = [{
//     nombre : "Aceite",
//     precio : 50000,
//     presentacion : "Tarro"
// },
// {
//     nombre : "Luz delantera",
//     precio : 120000,
//     presentacion : "Caja"
// },
// {
//     nombre : "Guardabarro",
//     precio : 70000,
//     presentacion : "Caja"
// }
// ];

// //guardar datos en localstorage
// localStorage.setItem("productos",  JSON.stringify(productos));
// alert("producto guardado con exito");

//traer datos guardados en el navegador
// let productosGuadados = JSON.parse(localStorage.getItem("productos"));
// let props = [];
// if (productosGuadados != null) {
//     props = productosGuadados;
// }

// props.forEach((d,i)=>{
//     document.write(
//         ` id: ${i+1} <br> 
//           Nombre Producto : ${d.nombre} <br>
//           precio producto : ${d.precio} <br>
//           Presentacion : ${d.presentacion}
//           <hr>
//         `
//     );  
// });

//declaracion de variables
let nombrePro = document.querySelector(".nombre-producto");
let presentacionPro = document.querySelector(".presentacion-producto");
let precioPro = document.querySelector(".precio-producto");
let imagenPro = document.querySelector(".imagen-producto");
let btnGuardar = document.querySelector(".btn-guardar");
let tabla = document.querySelector(".table > tbody");

//agregar evento al boton
btnGuardar.addEventListener("click", ()=> {
   // alert(nombrePro.value);
   let datos=obtenerProductos();
   if(datos != null){
      guardarDatos(datos);
   }
   borrarTabla();
   mostrarDatos();
});

//funcion para obtener los productos del formulario
function obtenerProductos() {
    if( nombrePro.value == "" || presentacionPro.value == "" || 
        precioPro.value == "" || imagenPro.value == ""
    ){
        alert("Todos los campos son obligatorios");
        return;
    }

    let producto = {
        nombre : nombrePro.value,
        presentacion : presentacionPro.value,
        precio : precioPro.value,
        imagen : imagenPro.value
    }
    nombrePro.value = "";
    presentacionPro.value = "";
    precioPro.value = "";
    imagenPro.value = "";
    return producto;
}
//Funsión guardar datos en localStorage
const listadoProductos = "Productos";
function guardarDatos(datos){
    let productos=[];
    //Extraer datos guardados previamente en el localStorage
    let productosPrevios = JSON.parse(localStorage.getItem(listadoProductos));
    //validar datos guardados previamente en el localStorage
    if(productosPrevios!=null){
        productos = productosPrevios;
    }
    //agregar el producto al nuevo array
    productos.push(datos);

    //guardar en LocalStorage
    localStorage.setItem(listadoProductos, JSON.stringify(productos));
    //validar que los datos fueron guardados
    alert("Datos guardados con exito")
}

//funcion para extraer datos guardados en localStorage
function mostrarDatos(){
    let productos=[];
    //Extraer datos guardados previamente en el localStorage
    let productosPrevios = JSON.parse(localStorage.getItem(listadoProductos));
    //validar datos guardados previamente en el localStorage
    if( productosPrevios!=null){
        productos = productosPrevios;
    }
    // console.log(productos);
    //mostrar datos en la tabla
    productos.forEach((p,i) => {
        let fila = document.createElement("tr");
        fila.innerHTML = `
        <td> ${i+1} </td>
        <td> ${p.nombre} </td>
        <td> ${p.presentacion} </td>
        <td> ${p.precio} </td>
        <td> <img src="${p.imagen}" width="50%"></td>
        <td>
            <span onclick="actualizarProducto(${i})" class="btn-editar btn btn-warning"> 📋 </span>
            <span onclick="eliminarProducto(${i})" class="btn-eliminar btn btn-danger"> ✖️ </span>
        </td>
        `;
        tabla.appendChild(fila);
    });
}

//quitar los datos de la tabla
function borrarTabla(){
    let filas=document.querySelectorAll(".table tbody tr");
    // console.log(filas)
    filas.forEach((f)=> {
        f.remove();
    })
}

//funcion eliminar un pedido de la tabla
function eliminarProducto(pos){
    let productos=[];
    //Extraer datos guardados previamente en el localStorage
    let productosPrevios = JSON.parse(localStorage.getItem(listadoProductos));
    //validar datos guardados previamente en el localStorage
    if( productosPrevios!=null){
        productos = productosPrevios;
    }
    //confirmar pedido a eliminar
    let confirmar = confirm("¿Deseas eliminar el producto: "+productos[pos].nombre+ "?")
    if(confirmar){
        // alert("Lo eliminaste");
        productos.splice(pos,1);
        alert("Producto eliminado con exito");
        //Guardar los datos que quedaron en localStorage
        localStorage.setItem(listadoProductos, JSON.stringify(productos));
        borrarTabla();
        mostrarDatos();
    }
}

//actualizar producto en localStorage
function actualizarProducto(pos){
    let productos=[];
    //Extraer datos guardados previamente en el localStorage
    let productosPrevios = JSON.parse(localStorage.getItem(listadoProductos));
    //validar datos guardados previamente en el localStorage
    if( productosPrevios!=null){
        productos = productosPrevios;
    }
    //pasar los datos al formulario para editarlos
    nombrePro.value = productos[pos].nombre;
    presentacionPro.value = productos[pos].presentacion;
    precioPro.value = productos[pos].precio;
    imagenPro.value = productos[pos].imagen;
    //Seleccionar el botón de actualizar
    let btnActualizar = document.querySelector(".btn-actualizar");
    btnActualizar.classList.toggle("d-none");
    btnGuardar.classList.toggle("d-none");
    //Agregar evento al boton actualizar
    btnActualizar.addEventListener("click",function(){
        productos[pos].nombre = nombrePro.value;
        productos[pos].presentacion = presentacionPro.value;
        productos[pos].precio = precioPro.value;
        productos[pos].imagen = imagenPro.value;
        //guardar los datos editados en localStorage
        localStorage.setItem(listadoProductos, JSON.stringify(productos));
        alert("El dato fue actualizado con exito")
        
        nombrePro.value = "";
        presentacionPro.value = "";
        precioPro.value = "";
        imagenPro.value = "";

        btnActualizar.classList.toggle("d-none");
        btnGuardar.classList.toggle("d-none");
        borrarTabla();
        mostrarDatos();
    });
}

//mostrar los datos de localStorage al recargar la pagina
document.addEventListener("DOMContentLoaded",function(){
    borrarTabla();
    mostrarDatos();
});

let inputBuscar = document.querySelector(".input-buscar");

// Agregar evento de escucha al input de búsqueda
inputBuscar.addEventListener("input", function() {
    // Obtener el texto de búsqueda
    let textoBusqueda = inputBuscar.value.toLowerCase();
    
    // Filtrar los productos en la tabla según el texto de búsqueda
    let productosFiltrados = JSON.parse(localStorage.getItem(listadoProductos)).filter(function(producto) {
        return producto.nombre.toLowerCase().includes(textoBusqueda);
    });
    
    // Limpiar la tabla antes de mostrar los resultados filtrados
    borrarTabla();
    
    // Mostrar los productos filtrados en la tabla
    productosFiltrados.forEach(function(producto, i) {
        let fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${i + 1}</td>
            <td>${producto.nombre}</td>
            <td>${producto.presentacion}</td>
            <td>${producto.precio}</td>
            <td><img src="${producto.imagen}" width="50%"></td>
            <td>
                <span onclick="actualizarProducto(${i})" class="btn-editar btn btn-warning">📋</span>
                <span onclick="eliminarProducto(${i})" class="btn-eliminar btn btn-danger">✖️</span>
            </td>
        `;
        tabla.appendChild(fila);
    });
});

// Actualizar la función mostrarDatos para que inicialice productos como un arreglo vacío si no hay datos previos en localStorage
function mostrarDatos() {
    let productos = JSON.parse(localStorage.getItem(listadoProductos)) || [];
    productos.forEach((p, i) => {
        let fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${i + 1}</td>
            <td>${p.nombre}</td>
            <td>${p.presentacion}</td>
            <td>${p.precio}</td>
            <td><img src="${p.imagen}" width="50%"></td>
            <td>
                <span onclick="actualizarProducto(${i})" class="btn-editar btn btn-warning">📋</span>
                <span onclick="eliminarProducto(${i})" class="btn-eliminar btn btn-danger">✖️</span>
            </td>
        `;
        tabla.appendChild(fila);
    });
}

// Inicializar la tabla al cargar la página
mostrarDatos();




